using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
using GaboLevels = NinjaTrader.Gui.NinjaScript.GaboLevels;
using GaboLevel = NinjaTrader.Gui.NinjaScript.GaboLevel;

namespace NinjaTrader.NinjaScript.Indicators
{
    public class GaboRiskLines : Indicator
    {
        private class RenderItem
        {
            public float Y;
            public string Text;
            public int Kind;
        }

        // Mouse y arrastre de zonas
        private ChartPanel hookedPanel;
        private ChartScale lastScale;
        private bool dragging;
        private bool hoverCursor;
        private int dragKind;                    // 0 = TP, 3 = SL
        private double dragStartPrice, dragPrice;
        private float zoneX0, zoneX1, tpY, slY;  // de la última pasada de dibujo, para saber dónde se puede agarrar
        private bool hasTp, hasSl;

        // Después de soltar, se sigue mostrando la zona donde la dejaste hasta que el panel publique los niveles nuevos
        private bool holding;
        private int holdKind, holdVersion;
        private double holdPrice;
        private DateTime holdUntil;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Carteles y zonas de GaboRiskPanelV2: TP, entrada, pendientes y SL con su resultado en USD. Las zonas se arrastran.";
                Name = "GaboRiskLines";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = false;
                PaintPriceMarkers = false;
                IsSuspendedWhileInactive = false;
                ShowLines = false;
                ShowZones = true;
                AllowDrag = true;
                ZoneBars = 30;
                LabelFontSize = 12;
            }
            else if (State == State.Terminated)
            {
                UnhookMouse();
            }
        }

        [NinjaScriptProperty]
        [Display(Name = "Dibujar líneas propias", GroupName = "Parámetros", Order = 0)]
        public bool ShowLines { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Dibujar zonas rojo y verde", GroupName = "Parámetros", Order = 1)]
        public bool ShowZones { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Zonas arrastrables", GroupName = "Parámetros", Order = 2)]
        public bool AllowDrag { get; set; }

        [NinjaScriptProperty]
        [Range(5, 300)]
        [Display(Name = "Ancho de las zonas si no hay hora de ejecución (velas)", GroupName = "Parámetros", Order = 3)]
        public int ZoneBars { get; set; }

        [NinjaScriptProperty]
        [Range(8, 24)]
        [Display(Name = "Tamaño de letra", GroupName = "Parámetros", Order = 4)]
        public int LabelFontSize { get; set; }

        // ---------- Mouse ----------

        // Se engancha la primera vez que se dibuja (ahí el panel del gráfico ya existe seguro). Hilo de la interfaz.
        private void HookMouse()
        {
            if (hookedPanel != null || ChartPanel == null) return;
            hookedPanel = ChartPanel;
            hookedPanel.PreviewMouseLeftButtonDown += OnPanelMouseDown;
            hookedPanel.PreviewMouseMove += OnPanelMouseMove;
            hookedPanel.PreviewMouseLeftButtonUp += OnPanelMouseUp;
            hookedPanel.PreviewMouseRightButtonDown += OnPanelRightDown;
            hookedPanel.MouseLeave += OnPanelMouseLeave;
        }

        private void UnhookMouse()
        {
            ChartPanel panel = hookedPanel;
            if (panel == null) return;
            hookedPanel = null;
            try
            {
                panel.Dispatcher.InvokeAsync(() =>
                {
                    panel.PreviewMouseLeftButtonDown -= OnPanelMouseDown;
                    panel.PreviewMouseMove -= OnPanelMouseMove;
                    panel.PreviewMouseLeftButtonUp -= OnPanelMouseUp;
                    panel.PreviewMouseRightButtonDown -= OnPanelRightDown;
                    panel.MouseLeave -= OnPanelMouseLeave;
                    if (dragging) panel.ReleaseMouseCapture();
                    dragging = false;
                    hoverCursor = false;
                    Mouse.OverrideCursor = null;
                });
            }
            catch { }
        }

        // Posición del mouse en píxeles del gráfico (el mouse viene en unidades de WPF, el dibujo en píxeles)
        private void MousePixels(MouseEventArgs e, out double px, out double py)
        {
            var pt = e.GetPosition(hookedPanel);
            double sx = 1, sy = 1;
            System.Windows.PresentationSource src = System.Windows.PresentationSource.FromVisual(hookedPanel);
            if (src != null && src.CompositionTarget != null)
            {
                sx = src.CompositionTarget.TransformToDevice.M11;
                sy = src.CompositionTarget.TransformToDevice.M22;
            }
            px = pt.X * sx;
            py = pt.Y * sy;
        }

        // 0 = borde del TP, 3 = borde del SL, -1 = nada
        private int HitTest(double px, double py)
        {
            if (!hasTp && !hasSl) return -1;
            if (px < zoneX0 - 4 || px > zoneX1 + 4) return -1;
            const double tol = 7;
            if (hasTp && Math.Abs(py - tpY) <= tol) return 0;
            if (hasSl && Math.Abs(py - slY) <= tol) return 3;
            return -1;
        }

        private void OnPanelMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (!AllowDrag || !ShowZones || lastScale == null || Instrument == null || hookedPanel == null) return;

                double px, py;
                MousePixels(e, out px, out py);
                int kind = HitTest(px, py);
                if (kind < 0) return;

                GaboLevel[] levels = GaboLevels.Get(Instrument.FullName);
                if (levels == null) return;
                double start = double.NaN;
                foreach (var l in levels)
                    if ((kind == 0 && l.Kind == 0) || (kind == 3 && (l.Kind == 3 || l.Kind == 4))) start = l.Price;
                if (double.IsNaN(start)) return;

                dragging = true;
                holding = false;
                dragKind = kind;
                dragStartPrice = start;
                dragPrice = start;
                hookedPanel.CaptureMouse();
                e.Handled = true;   // el gráfico no se mueve mientras arrastrás
                if (ChartControl != null) ChartControl.InvalidateVisual();
            }
            catch { dragging = false; }
        }

        private void OnPanelMouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (hookedPanel == null || lastScale == null || Instrument == null) return;

                double px, py;
                MousePixels(e, out px, out py);

                if (dragging)
                {
                    if (e.LeftButton != MouseButtonState.Pressed) { EndDrag(false); return; }
                    double price = lastScale.GetValueByY((float)py);
                    dragPrice = Instrument.MasterInstrument.RoundToTickSize(price);
                    e.Handled = true;
                    if (ChartControl != null) ChartControl.InvalidateVisual();
                    return;
                }

                bool over = AllowDrag && ShowZones && HitTest(px, py) >= 0;
                if (over != hoverCursor)
                {
                    hoverCursor = over;
                    Mouse.OverrideCursor = over ? Cursors.SizeNS : null;
                }
            }
            catch { }
        }

        private void OnPanelMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (!dragging) return;
            e.Handled = true;
            EndDrag(true);
        }

        // Botón derecho durante el arrastre: se cancela y la zona vuelve a donde estaba
        private void OnPanelRightDown(object sender, MouseButtonEventArgs e)
        {
            if (!dragging) return;
            e.Handled = true;
            EndDrag(false);
        }

        private void OnPanelMouseLeave(object sender, MouseEventArgs e)
        {
            if (dragging || !hoverCursor) return;
            hoverCursor = false;
            Mouse.OverrideCursor = null;
        }

        private void EndDrag(bool commit)
        {
            bool was = dragging;
            dragging = false;
            hoverCursor = false;
            try { if (hookedPanel != null) hookedPanel.ReleaseMouseCapture(); } catch { }
            Mouse.OverrideCursor = null;

            if (was && commit && Instrument != null)
            {
                double tick = Instrument.MasterInstrument.TickSize;
                if (Math.Abs(dragPrice - dragStartPrice) >= tick * 0.5)
                {
                    holding = true;
                    holdKind = dragKind;
                    holdPrice = dragPrice;
                    holdVersion = GaboLevels.Version;
                    holdUntil = DateTime.UtcNow.AddMilliseconds(3000);
                    GaboLevels.RaiseDrag(Instrument.FullName, dragKind, dragPrice,
                        hookedPanel != null ? System.Windows.Window.GetWindow(hookedPanel) : null);
                }
            }
            if (ChartControl != null) ChartControl.InvalidateVisual();
        }

        // ---------- Dibujo ----------

        // Relleno translúcido entre la entrada y el borde (TP o SL) y una línea más gruesa en el borde, que es lo que se agarra
        private void DrawZone(SharpDX.Direct2D1.Brush brush, float zx0, float zx1, float entryY, float edgeY,
            float panelTop, float panelBottom, bool active)
        {
            float a = Math.Min(entryY, edgeY);
            float b = Math.Max(entryY, edgeY);
            float ca = Math.Max(a, panelTop);
            float cb = Math.Min(b, panelBottom);
            if (cb > ca)
            {
                brush.Opacity = 0.14f;
                RenderTarget.FillRectangle(new SharpDX.RectangleF(zx0, ca, zx1 - zx0, cb - ca), brush);
            }
            if (edgeY >= panelTop && edgeY <= panelBottom)
            {
                brush.Opacity = 0.95f;
                RenderTarget.DrawLine(new SharpDX.Vector2(zx0, edgeY), new SharpDX.Vector2(zx1, edgeY), brush, active ? 3f : 2f);
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            hasTp = false;
            hasSl = false;
            if (Instrument == null || RenderTarget == null || ChartPanel == null) return;

            lastScale = chartScale;
            if (hookedPanel == null) HookMouse();

            GaboLevel[] levels = GaboLevels.Get(Instrument.FullName);
            if (levels == null || levels.Length == 0) return;

            double pv = Instrument.MasterInstrument.PointValue;
            double avg, sign; int qty;
            bool haveBasis = GaboLevels.Basis(levels, out avg, out qty, out sign);

            // ¿Hay una zona arrastrándose (o recién soltada y esperando al panel)? Si sí, se dibuja en el precio nuevo
            bool ov = false;
            int ovKind = 0;
            double ovPrice = 0;
            if (dragging)
            {
                ov = true; ovKind = dragKind; ovPrice = dragPrice;
            }
            else if (holding)
            {
                if (GaboLevels.Version != holdVersion || DateTime.UtcNow > holdUntil) holding = false;
                else { ov = true; ovKind = holdKind; ovPrice = holdPrice; }
            }

            var items = new List<RenderItem>();
            float entryY = float.NaN;
            foreach (var lv in levels)
            {
                double price = lv.Price;
                string text = lv.Text;
                bool tpEdge = lv.Kind == 0;
                bool slEdge = lv.Kind == 3 || lv.Kind == 4;

                if (ov && haveBasis)
                {
                    if (tpEdge && ovKind == 0)
                    {
                        price = ovPrice;
                        text = string.Format("TP {0} ({1:0.##} pts)", GaboLevels.Usd(GaboLevels.TargetPnl(levels, price, pv)), Math.Abs(price - avg));
                    }
                    else if (slEdge && ovKind == 3)
                    {
                        price = ovPrice;
                        text = string.Format("SL {0} ({1:0.##} pts)", GaboLevels.Usd(GaboLevels.StopPnl(levels, price, pv)), Math.Abs(price - avg));
                    }
                }

                float y = chartScale.GetYByValue(price);
                if (tpEdge) { tpY = y; hasTp = true; }
                if (slEdge) { slY = y; hasSl = true; }
                if (lv.Kind == 1) entryY = y;
                items.Add(new RenderItem { Y = y, Text = text, Kind = lv.Kind });
            }
            items.Sort((a, b) => a.Y.CompareTo(b.Y));   // de arriba hacia abajo en pantalla, aunque una zona se arrastre pasando otro nivel

            var factory = NinjaTrader.Core.Globals.DirectWriteFactory;
            float x0 = ChartPanel.X;
            float x1 = ChartPanel.X + ChartPanel.W;
            float h = LabelFontSize + 8f;
            float lastBottom = float.MinValue;

            // Zonas: desde unas velas atrás de la última hasta el borde derecho del gráfico
            bool zonesOk = false;
            float zx0 = 0, zx1 = 0;
            if (ShowZones && ChartBars != null && !float.IsNaN(entryY))
            {
                DateTime start = GaboLevels.StartTime(Instrument.FullName);
                if (start != DateTime.MinValue)
                {
                    // Desde el momento de la ejecución; si ya quedó fuera de la pantalla, desde el borde izquierdo
                    zx0 = Math.Max(chartControl.GetXByTime(start), x0);
                }
                else
                {
                    // Sin hora de ejecución conocida: unas velas atrás de la última
                    int toIdx = ChartBars.ToIndex;
                    int fromIdx = Math.Max(ChartBars.FromIndex, toIdx - ZoneBars);
                    zx0 = chartControl.GetXByBarIndex(ChartBars, fromIdx);
                }
                zx1 = x1 - 4f;
                zonesOk = zx1 - zx0 > 20f;
            }
            if (zonesOk) { zoneX0 = zx0; zoneX1 = zx1; }
            else { hasTp = false; hasSl = false; }

            using (var fmt = new SharpDX.DirectWrite.TextFormat(factory, "Arial", SharpDX.DirectWrite.FontWeight.Bold,
                SharpDX.DirectWrite.FontStyle.Normal, (float)LabelFontSize))
            using (var dash = new SharpDX.Direct2D1.StrokeStyle(NinjaTrader.Core.Globals.D2DFactory,
                new SharpDX.Direct2D1.StrokeStyleProperties { DashStyle = SharpDX.Direct2D1.DashStyle.Dash }))
            using (var greenZone = System.Windows.Media.Brushes.LimeGreen.ToDxBrush(RenderTarget))
            using (var redZone = System.Windows.Media.Brushes.Firebrick.ToDxBrush(RenderTarget))
            {
                if (zonesOk)
                {
                    float panelTop = ChartPanel.Y;
                    float panelBottom = ChartPanel.Y + ChartPanel.H;
                    if (hasTp) DrawZone(greenZone, zx0, zx1, entryY, tpY, panelTop, panelBottom, ov && ovKind == 0);
                    if (hasSl) DrawZone(redZone, zx0, zx1, entryY, slY, panelTop, panelBottom, ov && ovKind == 3);
                }

                foreach (var it in items)
                {
                    float y = it.Y;
                    if (y < ChartPanel.Y || y > ChartPanel.Y + ChartPanel.H) continue;

                    System.Windows.Media.Brush bgWpf, fgWpf;
                    switch (it.Kind)
                    {
                        case 0: bgWpf = System.Windows.Media.Brushes.LimeGreen; fgWpf = System.Windows.Media.Brushes.Black; break;    // TP
                        case 1: bgWpf = System.Windows.Media.Brushes.Silver; fgWpf = System.Windows.Media.Brushes.Black; break;       // entrada
                        case 2: bgWpf = System.Windows.Media.Brushes.Orange; fgWpf = System.Windows.Media.Brushes.Black; break;       // pendiente
                        default: bgWpf = System.Windows.Media.Brushes.Firebrick; fgWpf = System.Windows.Media.Brushes.White; break;   // SL
                    }

                    using (var bg = bgWpf.ToDxBrush(RenderTarget))
                    using (var fg = fgWpf.ToDxBrush(RenderTarget))
                    using (var layout = new SharpDX.DirectWrite.TextLayout(factory, it.Text, fmt, 700f, h))
                    {
                        if (ShowLines)
                        {
                            var p0 = new SharpDX.Vector2(x0, y);
                            var p1 = new SharpDX.Vector2(x1, y);
                            if (it.Kind == 2 || it.Kind == 4) RenderTarget.DrawLine(p0, p1, bg, 1f, dash);
                            else RenderTarget.DrawLine(p0, p1, bg, 1f);
                        }

                        float w = layout.Metrics.Width + 14f;
                        // Anclado a la última vela visible, a su derecha; si no hay margen, se frena antes de las X y el precio de NinjaTrader
                        float anchorX = ChartBars != null
                            ? chartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex) + 30f
                            : x1 - w - 60f;
                        float bx = Math.Max(Math.Min(anchorX, x1 - w - 40f), x0 + 4f);
                        float top = y - h - 2f;   // justo arriba de la línea, para no tapar los carteles nativos que van sobre ella
                        if (top < lastBottom + 1f) top = lastBottom + 1f;   // si dos niveles quedan pegados, el de abajo se corre
                        lastBottom = top + h;

                        bg.Opacity = 0.9f;
                        RenderTarget.FillRectangle(new SharpDX.RectangleF(bx, top, w, h), bg);
                        RenderTarget.DrawTextLayout(new SharpDX.Vector2(bx + 7f, top + (h - layout.Metrics.Height) / 2f), layout, fg);
                    }
                }
            }
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private GaboRiskLines[] cacheGaboRiskLines;
		public GaboRiskLines GaboRiskLines(bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			return GaboRiskLines(Input, showLines, showZones, allowDrag, zoneBars, labelFontSize);
		}

		public GaboRiskLines GaboRiskLines(ISeries<double> input, bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			if (cacheGaboRiskLines != null)
				for (int idx = 0; idx < cacheGaboRiskLines.Length; idx++)
					if (cacheGaboRiskLines[idx] != null && cacheGaboRiskLines[idx].ShowLines == showLines && cacheGaboRiskLines[idx].ShowZones == showZones && cacheGaboRiskLines[idx].AllowDrag == allowDrag && cacheGaboRiskLines[idx].ZoneBars == zoneBars && cacheGaboRiskLines[idx].LabelFontSize == labelFontSize && cacheGaboRiskLines[idx].EqualsInput(input))
						return cacheGaboRiskLines[idx];
			return CacheIndicator<GaboRiskLines>(new GaboRiskLines(){ ShowLines = showLines, ShowZones = showZones, AllowDrag = allowDrag, ZoneBars = zoneBars, LabelFontSize = labelFontSize }, input, ref cacheGaboRiskLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.GaboRiskLines GaboRiskLines(bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			return indicator.GaboRiskLines(Input, showLines, showZones, allowDrag, zoneBars, labelFontSize);
		}

		public Indicators.GaboRiskLines GaboRiskLines(ISeries<double> input , bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			return indicator.GaboRiskLines(input, showLines, showZones, allowDrag, zoneBars, labelFontSize);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.GaboRiskLines GaboRiskLines(bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			return indicator.GaboRiskLines(Input, showLines, showZones, allowDrag, zoneBars, labelFontSize);
		}

		public Indicators.GaboRiskLines GaboRiskLines(ISeries<double> input , bool showLines, bool showZones, bool allowDrag, int zoneBars, int labelFontSize)
		{
			return indicator.GaboRiskLines(input, showLines, showZones, allowDrag, zoneBars, labelFontSize);
		}
	}
}

#endregion
