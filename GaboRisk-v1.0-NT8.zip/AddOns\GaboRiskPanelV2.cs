using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.Gui.NinjaScript
{
    public class GaboRiskPanelV2 : AddOnBase
    {
        private readonly List<GaboRiskTabV2> tabs = new List<GaboRiskTabV2>();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "GaboRiskPanelV2";
                Description = "Gestor de riesgo fijo en USD con promediado";
            }
            else if (State == State.Terminated)
            {
                // Al recompilar o cerrar: soltar eventos y sacar el panel para no dejar copias viejas escuchando
                lock (tabs)
                {
                    foreach (var t in tabs) t.Dispose();
                    tabs.Clear();
                }
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            NinjaTrader.Gui.Chart.Chart chartWindow = window as NinjaTrader.Gui.Chart.Chart;
            if (chartWindow == null) return;

            window.Dispatcher.InvokeAsync(() =>
            {
                var tab = new GaboRiskTabV2(chartWindow);
                lock (tabs) tabs.Add(tab);
                tab.Attach();
            });
        }

        protected override void OnWindowDestroyed(Window window)
        {
            lock (tabs)
            {
                foreach (var t in tabs.Where(x => x.Owner == window).ToList())
                {
                    t.Dispose();
                    tabs.Remove(t);
                }
            }
        }
    }

    public class GaboLevel
    {
        public double Price;
        public string Text;
        public int Kind;   // 0 TP, 1 entrada, 2 pendiente, 3 SL, 4 SL proyectado (con pendientes)
        public int Qty;    // contratos de la entrada y de cada pendiente (para calcular el PnL al arrastrar una zona)
    }

    // Niveles que arma el panel y lee el indicador GaboRiskLines (uno por instrumento)
    public static class GaboLevels
    {
        private static readonly object lk = new object();
        private static readonly Dictionary<string, GaboLevel[]> map = new Dictionary<string, GaboLevel[]>();
        private static readonly Dictionary<string, DateTime> startTimes = new Dictionary<string, DateTime>();

        public static void Set(string instrument, GaboLevel[] levels)
        {
            if (instrument == null) return;
            lock (lk)
            {
                if (levels == null || levels.Length == 0) { map.Remove(instrument); startTimes.Remove(instrument); }
                else
                {
                    map[instrument] = levels;
                    // La primera vez que hay niveles para una posición nueva queda guardada la hora de la ejecución
                    if (!startTimes.ContainsKey(instrument)) startTimes[instrument] = Core.Globals.Now;
                }
            }
            Interlocked.Increment(ref Version);
        }

        public static GaboLevel[] Get(string instrument)
        {
            lock (lk)
            {
                GaboLevel[] r;
                return map.TryGetValue(instrument, out r) ? r : null;
            }
        }

        // Hora en que arrancó la posición actual (hora de NinjaTrader, la misma de las velas); MinValue si no se sabe
        public static DateTime StartTime(string instrument)
        {
            lock (lk)
            {
                DateTime t;
                return startTimes.TryGetValue(instrument, out t) ? t : DateTime.MinValue;
            }
        }

        // Sube cada vez que se publican niveles nuevos. El indicador lo usa para saber cuándo soltar una zona arrastrada.
        public static int Version;

        public static void Touch()
        {
            Interlocked.Increment(ref Version);
        }

        // El indicador avisa acá cuando soltás una zona: instrumento, tipo (0 = TP, 3 = SL), precio nuevo y la ventana del gráfico donde la soltaste
        public static event Action<string, int, double, object> ZoneDragged;

        public static void RaiseDrag(string instrument, int kind, double price, object owner)
        {
            Action<string, int, double, object> h = ZoneDragged;
            if (h != null) h(instrument, kind, price, owner);
        }

        public static string Usd(double v)
        {
            return (v < 0 ? "-$" : "+$") + Math.Abs(v).ToString("0");
        }

        // Promedio, contratos y dirección (+1 long, -1 short) de la posición, sacados de los niveles publicados
        public static bool Basis(GaboLevel[] lv, out double avg, out int qty, out double sign)
        {
            avg = 0; qty = 0; sign = 1;
            if (lv == null) return false;
            GaboLevel entry = null, tp = null;
            foreach (var l in lv)
            {
                if (l.Kind == 1) entry = l;
                else if (l.Kind == 0) tp = l;
            }
            if (entry == null || tp == null || entry.Qty <= 0) return false;
            avg = entry.Price;
            qty = entry.Qty;
            sign = tp.Price >= entry.Price ? 1 : -1;
            return true;
        }

        // Resultado en USD si el SL estuviera en 'stop' (suma las pendientes en contra que se ejecutan antes de llegar ahí)
        public static double StopPnl(GaboLevel[] lv, double stop, double pointValue)
        {
            double avg, sign; int qty;
            if (!Basis(lv, out avg, out qty, out sign)) return 0;
            double sum = (stop - avg) * qty;
            foreach (var l in lv)
                if (l.Kind == 2 && l.Qty > 0 && sign * (l.Price - stop) > 0) sum += (stop - l.Price) * l.Qty;
            return sum * sign * pointValue;
        }

        // Resultado en USD si el TP estuviera en 'target'
        public static double TargetPnl(GaboLevel[] lv, double target, double pointValue)
        {
            double avg, sign; int qty;
            if (!Basis(lv, out avg, out qty, out sign)) return 0;
            return (target - avg) * qty * pointValue * sign;
        }
    }

    // Resultado del día de una cuenta: baseline del PnL realizado al empezar el día y si ese día quedó bloqueado.
    // Se guarda en un archivo para que un reinicio de NinjaTrader o una recompilación no desbloquee el día ni borre los límites.
    public class GaboDayInfo
    {
        public string Account;
        public DateTime Day;
        public double Baseline;
        public string Lock;   // null = libre; si no, el motivo del bloqueo
    }

    public static class GaboDayStore
    {
        private static readonly object lk = new object();
        private static readonly Dictionary<string, GaboDayInfo> days = new Dictionary<string, GaboDayInfo>();
        private static double limProfit, limLoss;
        private static bool loaded;

        private static string FilePath()
        {
            return System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "GaboRiskDay.txt");
        }

        private static string Key(string account, DateTime day)
        {
            return account + "|" + day.ToString("yyyyMMdd");
        }

        private static double ParseNum(string s)
        {
            double v;
            if (double.TryParse(s, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v)) return v;
            return 0;
        }

        private static string Num(double v)
        {
            return v.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
        }

        // Siempre dentro del lock
        private static void Load()
        {
            if (loaded) return;
            loaded = true;
            try
            {
                string path = FilePath();
                if (!System.IO.File.Exists(path)) return;
                foreach (string line in System.IO.File.ReadAllLines(path))
                {
                    string[] f = line.Split('|');
                    if (f.Length >= 3 && f[0] == "L")
                    {
                        limProfit = ParseNum(f[1]);
                        limLoss = ParseNum(f[2]);
                    }
                    else if (f.Length >= 5 && f[0] == "D")
                    {
                        DateTime d;
                        if (!DateTime.TryParseExact(f[2], "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None, out d)) continue;
                        var info = new GaboDayInfo { Account = f[1], Day = d, Baseline = ParseNum(f[3]), Lock = f[4].Length == 0 ? null : f[4] };
                        days[Key(info.Account, d)] = info;
                    }
                }
            }
            catch { }
        }

        // Siempre dentro del lock
        private static void Save()
        {
            try
            {
                var lines = new List<string>();
                lines.Add("L|" + Num(limProfit) + "|" + Num(limLoss));
                DateTime oldest = DateTime.Now.Date.AddDays(-7);
                foreach (var info in days.Values)
                    if (info.Day >= oldest)
                        lines.Add("D|" + info.Account + "|" + info.Day.ToString("yyyyMMdd") + "|" + Num(info.Baseline) + "|" + (info.Lock ?? ""));
                System.IO.File.WriteAllLines(FilePath(), lines.ToArray());
            }
            catch { }
        }

        // El día de la cuenta; si todavía no existe, se crea con el PnL realizado de ahora como punto de partida
        public static GaboDayInfo Get(string account, DateTime day, double realizedNow)
        {
            lock (lk)
            {
                Load();
                GaboDayInfo info;
                if (!days.TryGetValue(Key(account, day), out info))
                {
                    info = new GaboDayInfo { Account = account, Day = day, Baseline = realizedNow, Lock = null };
                    days[Key(account, day)] = info;
                    Save();
                }
                return info;
            }
        }

        public static void SetLock(string account, DateTime day, string reason, double realizedNow)
        {
            lock (lk)
            {
                Load();
                GaboDayInfo info;
                if (!days.TryGetValue(Key(account, day), out info))
                {
                    info = new GaboDayInfo { Account = account, Day = day, Baseline = realizedNow };
                    days[Key(account, day)] = info;
                }
                info.Lock = reason;
                Save();
            }
        }

        // Desbloquea y vuelve a contar el día desde cero
        public static void Reset(string account, DateTime day, double realizedNow)
        {
            lock (lk)
            {
                Load();
                days[Key(account, day)] = new GaboDayInfo { Account = account, Day = day, Baseline = realizedNow, Lock = null };
                Save();
            }
        }

        public static void GetLimits(out double profit, out double loss)
        {
            lock (lk)
            {
                Load();
                profit = limProfit;
                loss = limLoss;
            }
        }

        public static void SetLimits(double profit, double loss)
        {
            lock (lk)
            {
                Load();
                if (profit == limProfit && loss == limLoss) return;
                limProfit = profit;
                limLoss = loss;
                Save();
            }
        }
    }

    public class GaboRiskTabV2
    {
        public Grid Panel;
        public TabItem Item;   // solo si no se pudo pegar al Chart Trader
        public Window Owner { get { return chartWindow; } }

        // Guardrail: el SL y el TP nuevos deben quedar al menos estos ticks lejos del precio
        private const int MinTicksAway = 4;

        private readonly NinjaTrader.Gui.Chart.Chart chartWindow;
        private NinjaTrader.Gui.Chart.ChartTrader chartTrader;
        private AccountSelector accountSelector;
        private Grid mainGrid;
        private RowDefinition dockedRow;

        private Account account;
        private Instrument instrument;
        private double lastPrice;

        private TextBox riskBox, profitBox, qtyBox, maxBox, beBox, trailBox, cushionBox;
        private TextBlock statusText, levelsText;

        private Order slOrder, tpOrder;
        private volatile bool disposed;

        // Mientras se cierra todo, los cambios de posición NO deben volver a armar SL/TP.
        // closeEpoch invalida los chequeos diferidos si el usuario entra de nuevo a mercado.
        private volatile bool closing;
        private int closeEpoch;

        // Para juntar varios avisos de órdenes seguidos en un solo recálculo
        private int rebuildTicket;

        // Copia de los valores de los cuadros. Los eventos de la cuenta corren en otro hilo
        // y NO pueden leer un TextBox directo.
        private volatile int maxCached = 10;

        // Break-even y trailing (en USD de toda la posición; 0 = apagado)
        private double beCached = 0, trailCached = 0;
        // Colchón del break-even en USD: el SL va a entrada + colchón para cubrir comisiones
        private double cushionCached = 10;
        // Botón Trailing: si está en ON y el cuadro Trailing $ está en 0, usa esta fracción del Profit $ como distancia
        private const double TrailDefaultFraction = 0.5;
        private volatile bool trailBtnOn;
        private Button trailBtn;

        // Límite diario (0 = apagado). El día bloqueado se guarda en archivo (GaboDayStore)
        private TextBox dayProfitBox, dayLossBox;
        private TextBlock dayText;
        private double dayMaxProfitCached = 0, dayMaxLossCached = 0;
        private volatile bool dayLocked;
        private string dayLockReason = "";
        private int dayBusy, lastDayCheck;
        private string lastDayText;
        private bool lastDayLocked;
        // Si el SL ya se movió a favor, se recuerda para no volver a alejarlo al recalcular
        private double lockedStop, lockedAvg;
        private int lockedQty;
        private int manageBusy, lastManage;

        // Cambios en vivo de Riesgo $ y Profit $
        private double appliedRisk = 1000, appliedProfit = 1000;   // últimos valores aplicados
        private double goodRisk = 1000, goodProfit = 1000;         // últimos con los que se armó bien la protección
        private volatile bool liveChange;
        private double riskCached = 1000, profitCached = 1000;
        private readonly object cacheLock = new object();

        // Compartido entre gráficos: evita que dos paneles armen la misma protección dos veces
        private static readonly object globalLock = new object();
        private static readonly Dictionary<string, string> built = new Dictionary<string, string>();

        public GaboRiskTabV2(NinjaTrader.Gui.Chart.Chart window)
        {
            chartWindow = window;
        }

        // Hilo de la interfaz. Intenta pegar el panel al final del Chart Trader; si no puede, usa una pestaña.
        public void Attach()
        {
            try
            {
                chartTrader = chartWindow.FindFirst("ChartWindowChartTraderControl") as NinjaTrader.Gui.Chart.ChartTrader;
                accountSelector = chartWindow.FindFirst("ChartTraderControlAccountSelector") as AccountSelector;
                mainGrid = chartTrader != null ? chartTrader.FindName("grdMain") as Grid : null;
            }
            catch { }

            if (accountSelector != null) accountSelector.SelectionChanged += OnAccountSelectionChanged;
            GaboLevels.ZoneDragged += OnZoneDragged;

            RefreshInstrument();
            BuildUi();
            ConnectAccount();

            if (mainGrid != null)
            {
                dockedRow = new RowDefinition { Height = GridLength.Auto };
                mainGrid.RowDefinitions.Add(dockedRow);
                Grid.SetRow(Panel, mainGrid.RowDefinitions.Count - 1);
                Grid.SetColumnSpan(Panel, Math.Max(1, mainGrid.ColumnDefinitions.Count));
                mainGrid.Children.Add(Panel);
            }
            else
            {
                Item = new TabItem { Header = "GaboRisk", Content = Panel };
                chartWindow.MainTabControl.Items.Add(Item);
            }
        }

        public void Dispose()
        {
            disposed = true;
            try { DisconnectAccount(); } catch { }
            try { if (instrument != null) instrument.MarketDataUpdate -= OnMarketData; } catch { }
            try { if (accountSelector != null) accountSelector.SelectionChanged -= OnAccountSelectionChanged; } catch { }
            try { GaboLevels.ZoneDragged -= OnZoneDragged; } catch { }

            try
            {
                chartWindow.Dispatcher.InvokeAsync(() =>
                {
                    if (mainGrid != null && Panel != null)
                    {
                        mainGrid.Children.Remove(Panel);
                        if (dockedRow != null)
                        {
                            // Solo se saca la fila si sigue siendo la última; si no, se colapsa para no mover otras
                            if (mainGrid.RowDefinitions.IndexOf(dockedRow) == mainGrid.RowDefinitions.Count - 1)
                                mainGrid.RowDefinitions.Remove(dockedRow);
                            else
                                dockedRow.Height = new GridLength(0);
                        }
                    }
                    if (Item != null && chartWindow.MainTabControl != null)
                        chartWindow.MainTabControl.Items.Remove(Item);
                });
            }
            catch { }
        }

        // ---------- Interfaz ----------

        private void BuildUi()
        {
            Panel = new Grid { Margin = new Thickness(4, 8, 4, 8) };
            Panel.ColumnDefinitions.Add(new ColumnDefinition());
            Panel.ColumnDefinitions.Add(new ColumnDefinition());
            for (int i = 0; i < 17; i++) Panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            riskBox = MakeBox("1000");
            profitBox = MakeBox("1000");
            qtyBox = MakeBox("1");
            maxBox = MakeBox("10");
            beBox = MakeBox("0");
            trailBox = MakeBox("0");
            cushionBox = MakeBox("10");
            double limP, limL;
            GaboDayStore.GetLimits(out limP, out limL);
            dayMaxProfitCached = limP;
            dayMaxLossCached = limL;
            dayProfitBox = MakeBox(limP.ToString("0.##"));
            dayLossBox = MakeBox(limL.ToString("0.##"));

            Place(MakeLabel("Riesgo $"), 0, 0);
            Place(MakeLabel("Profit $"), 0, 1);
            Place(riskBox, 1, 0);
            Place(profitBox, 1, 1);
            Place(MakeLabel("Contratos"), 2, 0);
            Place(MakeLabel("Máx. contratos"), 2, 1);
            Place(qtyBox, 3, 0);
            Place(maxBox, 3, 1);
            Place(MakeLabel("Break-even $"), 4, 0);
            Place(MakeLabel("Trailing $"), 4, 1);
            Place(beBox, 5, 0);
            Place(trailBox, 5, 1);

            
            
            
            
            

            Place(MakeButton("Buy", (s, e) => Enter(OrderAction.Buy)), 6, 0);
            Place(MakeButton("Sell", (s, e) => Enter(OrderAction.SellShort)), 6, 1);
            Place(MakeButton("Cerrar todo", (s, e) => { RefreshInstrument(); ConnectAccount(); CloseAll(); }), 7, 0, 2);

            // Break-even y trailing con un toque, sin escribir ningún valor
            Place(MakeButton("BE ya", (s, e) => BreakEvenNow()), 8, 0);
            trailBtn = MakeButton("Trailing: OFF", (s, e) => ToggleTrailing());
            Place(trailBtn, 8, 1);

            Place(MakeLabel("Colchón BE $ (comisiones)"), 9, 0, 2);
            Place(cushionBox, 10, 0);

            // Límite diario: al llegar a la ganancia máxima o a la pérdida máxima se cierra todo y no deja operar más ese día
            Place(MakeLabel("Ganancia máx. $"), 11, 0);
            Place(MakeLabel("Pérdida máx. $"), 11, 1);
            Place(dayProfitBox, 12, 0);
            Place(dayLossBox, 12, 1);
            dayText = new TextBlock { Text = "Día: -", Foreground = Brushes.LightGray, Margin = new Thickness(2, 6, 2, 0), TextWrapping = TextWrapping.Wrap };
            Place(dayText, 13, 0, 2);
            Place(MakeButton("Reiniciar día", (s, e) => ResetDay()), 14, 0, 2);

            statusText = new TextBlock { Foreground = Brushes.LightGray, Margin = new Thickness(0, 8, 0, 0), TextWrapping = TextWrapping.Wrap };
            Place(statusText, 15, 0, 2);

            levelsText = new TextBlock { Foreground = Brushes.LightGray, Margin = new Thickness(0, 6, 0, 0), TextWrapping = TextWrapping.Wrap, FontFamily = new FontFamily("Consolas"), FontSize = 11 };
            Place(levelsText, 16, 0, 2);
        }

        private void Place(UIElement el, int row, int col, int colSpan = 1)
        {
            Grid.SetRow(el, row);
            Grid.SetColumn(el, col);
            if (colSpan > 1) Grid.SetColumnSpan(el, colSpan);
            Panel.Children.Add(el);
        }

        private TextBlock MakeLabel(string text)
        {
            return new TextBlock { Text = text, Foreground = Brushes.LightGray, Margin = new Thickness(2, 6, 2, 2), TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Bottom };
        }

        private TextBox MakeBox(string value)
        {
            var tb = new TextBox { Text = value, Margin = new Thickness(2, 0, 2, 0) };

            // El gráfico se queda las teclas y abre el buscador de instrumentos. Se atienden a mano en PreviewKeyDown.
            tb.PreviewKeyDown += OnNumericKeyDown;
            tb.GotKeyboardFocus += (s, e) => { tb.SelectAll(); };
            tb.LostKeyboardFocus += (s, e) => ApplyLiveFields();   // al salir del cuadro se aplica el valor
            return tb;
        }

        // Marca la tecla como manejada (así el gráfico no abre el buscador) y escribe/borra el texto a mano.
        // Solo números enteros, que es lo que usan estos campos.
        private void OnNumericKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            var tb = sender as TextBox;
            if (tb == null) return;

            System.Windows.Input.Key k = e.Key;
            string digit = null;
            if (k >= System.Windows.Input.Key.D0 && k <= System.Windows.Input.Key.D9)
                digit = ((int)k - (int)System.Windows.Input.Key.D0).ToString();
            else if (k >= System.Windows.Input.Key.NumPad0 && k <= System.Windows.Input.Key.NumPad9)
                digit = ((int)k - (int)System.Windows.Input.Key.NumPad0).ToString();

            if (digit != null) { InsertText(tb, digit); return; }

            int st = tb.SelectionStart;
            int len = tb.SelectionLength;
            switch (k)
            {
                case System.Windows.Input.Key.Back:
                    if (len > 0) InsertText(tb, "");
                    else if (st > 0) { tb.Text = tb.Text.Remove(st - 1, 1); tb.SelectionStart = st - 1; tb.SelectionLength = 0; }
                    break;
                case System.Windows.Input.Key.Delete:
                    if (len > 0) InsertText(tb, "");
                    else if (st < tb.Text.Length) { tb.Text = tb.Text.Remove(st, 1); tb.SelectionStart = st; tb.SelectionLength = 0; }
                    break;
                case System.Windows.Input.Key.Left:
                    if (len > 0) tb.SelectionLength = 0;
                    else tb.SelectionStart = Math.Max(0, st - 1);
                    break;
                case System.Windows.Input.Key.Right:
                    if (len > 0) { tb.SelectionStart = st + len; tb.SelectionLength = 0; }
                    else tb.SelectionStart = Math.Min(tb.Text.Length, st + 1);
                    break;
                case System.Windows.Input.Key.Enter:
                    ApplyLiveFields();   // Enter aplica el valor
                    break;
                case System.Windows.Input.Key.Home:
                    tb.SelectionStart = 0; tb.SelectionLength = 0;
                    break;
                case System.Windows.Input.Key.End:
                    tb.SelectionStart = tb.Text.Length; tb.SelectionLength = 0;
                    break;
            }
        }

        private static void InsertText(TextBox tb, string text)
        {
            int st = tb.SelectionStart;
            tb.SelectedText = text;
            tb.SelectionStart = st + text.Length;
            tb.SelectionLength = 0;
        }

        private static TextBlock BtnText(string text)
        {
            return new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center };
        }

        private Button MakeButton(string text, RoutedEventHandler handler)
        {
            // El texto del botón se parte en dos renglones si el panel está angosto (no se corta)
            var b = new Button { Content = BtnText(text), Margin = new Thickness(2, 6, 2, 0), MinHeight = 28, Padding = new Thickness(2, 3, 2, 3) };
            b.Click += handler;
            return b;
        }

        // ---------- Cuenta, instrumento y precio ----------

        // Solo hilo de la interfaz
        private void RefreshInstrument()
        {
            Instrument inst = null;
            try
            {
                if (chartTrader != null) inst = chartTrader.Instrument;
                if (inst == null && chartWindow.ActiveChartControl != null) inst = chartWindow.ActiveChartControl.Instrument;
            }
            catch { }

            if (inst == null || inst == instrument) return;

            if (instrument != null) instrument.MarketDataUpdate -= OnMarketData;
            instrument = inst;
            lastPrice = 0;
            instrument.MarketDataUpdate += OnMarketData;
        }

        private void OnMarketData(object sender, MarketDataEventArgs e)
        {
            if (e.MarketDataType == MarketDataType.Last)
            {
                lastPrice = e.Price;
                TryManageStop();
                TryCheckDay();
            }
        }

        private void OnAccountSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ConnectAccount();
        }

        private void DisconnectAccount()
        {
            if (account == null) return;
            account.PositionUpdate -= OnPositionUpdate;
            account.OrderUpdate -= OnOrderUpdate;
            account = null;
        }

        // Toma la cuenta elegida en el selector del Chart Trader. Si no hay selector, usa Sim101.
        // También se llama al apretar cualquier botón, por si el aviso de cambio de cuenta llega tarde.
        private void ConnectAccount()
        {
            Account sel = null;
            if (accountSelector != null)
                sel = accountSelector.SelectedAccount;
            else
                lock (Account.All) sel = Account.All.FirstOrDefault(a => a.Name == "Sim101");

            if (sel == account) return;

            DisconnectAccount();
            if (sel == null) { SetStatus("Sin cuenta seleccionada"); return; }

            account = sel;
            account.PositionUpdate += OnPositionUpdate;
            account.OrderUpdate += OnOrderUpdate;
            SetStatus("Conectado a " + account.Name);
        }

        private double PointValue { get { return instrument.MasterInstrument.PointValue; } }

        private double Round(double price)
        {
            return instrument.MasterInstrument.RoundToTickSize(price);
        }

        // ---------- Campos ----------

        // Solo hilo de la interfaz: copia los cuadros a las variables que usan los eventos.
        private void SyncFields()
        {
            double r, p; int m;
            lock (cacheLock)
            {
                if (double.TryParse(riskBox.Text, out r) && r > 0) riskCached = r;
                if (double.TryParse(profitBox.Text, out p) && p > 0) profitCached = p;
            }
            if (int.TryParse(maxBox.Text, out m) && m > 0) maxCached = m;

            double b, t, c, dp, dl;
            lock (cacheLock)
            {
                if (double.TryParse(beBox.Text, out b) && b >= 0) beCached = b;
                if (double.TryParse(trailBox.Text, out t) && t >= 0) trailCached = t;
                if (double.TryParse(cushionBox.Text, out c) && c >= 0) cushionCached = c;
                if (double.TryParse(dayProfitBox.Text, out dp) && dp >= 0) dayMaxProfitCached = dp;
                if (double.TryParse(dayLossBox.Text, out dl) && dl >= 0) dayMaxLossCached = dl;
            }
        }

        // Solo hilo de la interfaz (botones). Valida y avisa si algo está mal.
        private bool ReadFields(out double risk, out double profit, out int qty)
        {
            risk = profit = 0; qty = 0;
            int max;
            if (!double.TryParse(riskBox.Text, out risk) || risk <= 0) { SetStatus("Riesgo inválido"); return false; }
            if (!double.TryParse(profitBox.Text, out profit) || profit <= 0) { SetStatus("Profit inválido"); return false; }
            if (!int.TryParse(qtyBox.Text, out qty) || qty <= 0) { SetStatus("Cantidad inválida"); return false; }
            if (!int.TryParse(maxBox.Text, out max) || max <= 0) { SetStatus("Máximo de contratos inválido"); return false; }
            SyncFields();
            return true;
        }

        // ---------- Órdenes ----------

        // Estados en los que la orden ya terminó o ya se está cancelando: no hay nada que cancelar.
        private static bool IsDone(OrderState s)
        {
            return s == OrderState.Filled || s == OrderState.Cancelled || s == OrderState.Rejected
                || s == OrderState.CancelPending || s == OrderState.CancelSubmitted;
        }

        private Order[] SnapshotOrders(Func<Order, bool> filter)
        {
            lock (account.Orders)
                return account.Orders.Where(filter).ToArray();
        }

        // Cancela TODO lo que siga vivo en este instrumento (SL, TP y promediadas pendientes), sin filtrar por estado.
        private void CancelAllOpen()
        {
            var open = SnapshotOrders(o => o.Instrument == instrument && !IsDone(o.OrderState));
            if (open.Length > 0) account.Cancel(open);
        }

        private bool IsFlat()
        {
            Position pos;
            lock (account.Positions) pos = account.Positions.FirstOrDefault(x => x.Instrument == instrument);
            return pos == null || pos.MarketPosition == MarketPosition.Flat;
        }

        // Revisa máximo de contratos y que el SL/TP resultantes queden a una distancia sana del precio.
        private bool PassesGuardrails(OrderAction action, int q, double risk, double profit, out string why)
        {
            why = null;
            bool isBuy = action == OrderAction.Buy;

            Position pos;
            lock (account.Positions) pos = account.Positions.FirstOrDefault(x => x.Instrument == instrument);
            MarketPosition cur = pos != null ? pos.MarketPosition : MarketPosition.Flat;
            int curQty = pos != null ? pos.Quantity : 0;
            double curAvg = pos != null ? pos.AveragePrice : 0;

            bool adding = cur == MarketPosition.Flat
                || (isBuy && cur == MarketPosition.Long)
                || (!isBuy && cur == MarketPosition.Short);
            if (!adding) return true;   // reduce o invierte: no aplican estos controles

            int newQty = curQty + q;
            if (newQty > maxCached)
            {
                why = string.Format("superás el máximo de {0} contratos (tendrías {1})", maxCached, newQty);
                return false;
            }

            double price = lastPrice;
            if (price <= 0) return true;   // sin precio todavía: no se puede validar

            double newAvg = curQty == 0 ? price : (curAvg * curQty + price * q) / newQty;
            double slDist = risk / (newQty * PointValue);
            double tpDist = profit / (newQty * PointValue);
            double minDist = MinTicksAway * instrument.MasterInstrument.TickSize;

            double slPrice = isBuy ? newAvg - slDist : newAvg + slDist;
            double tpPrice = isBuy ? newAvg + tpDist : newAvg - tpDist;
            double slGap = isBuy ? price - slPrice : slPrice - price;
            double tpGap = isBuy ? tpPrice - price : price - tpPrice;

            if (slGap < minDist)
            {
                why = "el SL nuevo quedaría pegado o detrás del precio (subí el riesgo o bajá contratos)";
                return false;
            }
            if (tpGap < minDist)
            {
                why = "el TP nuevo quedaría pegado o detrás del precio (subí el profit o bajá contratos)";
                return false;
            }
            return true;
        }

        private void Enter(OrderAction action)
        {
            try
            {
                RefreshInstrument();
                ConnectAccount();
                if (account == null || instrument == null) { SetStatus("Sin cuenta o instrumento"); return; }

                double r, p; int q;
                if (EvaluateDay()) { SetStatus("Bloqueado hasta mañana: " + dayLockReason); return; }
                if (!ReadFields(out r, out p, out q)) return;

                string why;
                if (!PassesGuardrails(action, q, r, p, out why)) { SetStatus("Bloqueado: " + why); return; }

                // Entrada nueva: invalida cualquier cierre diferido y vuelve a armar protección
                Interlocked.Increment(ref closeEpoch);
                closing = false;

                Order o = account.CreateOrder(instrument, action, OrderType.Market, OrderEntry.Manual,
                    TimeInForce.Day, q, 0, 0, "", "GaboEntry", Core.Globals.MaxDate, null);
                account.Submit(new[] { o });
            }
            catch (Exception ex) { SetStatus("Error entrada: " + ex.Message); }
        }

        // La posición se actualiza DESPUÉS del fill, así que se reacciona a este evento (trae cantidad y promedio
        // ya actualizados) y no al de ejecución, que ve la posición anterior.
        private void OnPositionUpdate(object sender, PositionEventArgs e)
        {
            if (disposed || closing) return;
            try
            {
                if (dayLocked && e.Position != null && e.MarketPosition != MarketPosition.Flat)
                {
                    LockAndFlatten("Día bloqueado (" + dayLockReason + "): se cerró la posición que se abrió.");
                    return;
                }
                if (e.Position == null || e.Position.Instrument != instrument) return;
                RebuildProtection(e.MarketPosition, e.Quantity, e.AveragePrice);
            }
            catch (Exception ex) { SetStatus("Error posición: " + ex.Message); }
        }

        private void OnOrderUpdate(object sender, OrderEventArgs e)
        {
            if (disposed || closing) return;
            try
            {
                if (e.Order.Instrument != instrument) return;

                bool isProt = e.Order.Name != null && e.Order.Name.StartsWith("GaboProt");

                if (isProt)
                {
                    // Se ejecutó el SL o el TP (incluso si lo moviste a mano, p. ej. a break-even)
                    if (e.OrderState == OrderState.Filled) OnProtectionFilled(e.Order.Name);
                    return;
                }

                // Día bloqueado: se cancelan las entradas pendientes (las de cierre no se tocan)
                if (dayLocked && (e.OrderState == OrderState.Accepted || e.OrderState == OrderState.Working)
                    && (e.Order.OrderAction == OrderAction.Buy || e.Order.OrderAction == OrderAction.SellShort)
                    && e.Order.OrderType != OrderType.Market && IsFlat())
                {
                    account.Cancel(new[] { e.Order });
                    SetStatus("Bloqueado hasta mañana: " + dayLockReason);
                    return;
                }

                // Guardrail de máximo de contratos para órdenes pendientes nativas
                EnforceMaxOnPending(e.Order);

                // Cualquier otra orden (por ejemplo promediadas pendientes que ponés vos): recalcular el SL
                ScheduleRebuild();
            }
            catch (Exception ex) { SetStatus("Error orden: " + ex.Message); }
        }

        // Junta varios avisos seguidos en un solo recálculo, un instante después (cuando la posición ya se actualizó)
        private void ScheduleRebuild()
        {
            int ticket = Interlocked.Increment(ref rebuildTicket);
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    Thread.Sleep(300);
                    if (Volatile.Read(ref rebuildTicket) != ticket || disposed || closing) return;
                    RebuildFromAccount();
                }
                catch (Exception ex) { SetStatus("Error recálculo: " + ex.Message); }
            });
        }

        private void RebuildFromAccount()
        {
            if (account == null || instrument == null) return;
            Position pos;
            lock (account.Positions) pos = account.Positions.FirstOrDefault(x => x.Instrument == instrument);
            MarketPosition dir = pos != null ? pos.MarketPosition : MarketPosition.Flat;
            RebuildProtection(dir, pos != null ? pos.Quantity : 0, pos != null ? pos.AveragePrice : 0);
        }

        // El SL/TP tiene el mismo tamaño que la posición, así que su fill ya la cierra. NO se manda un cierre a mercado
        // enseguida: la posición todavía figura abierta y ese cierre extra abría una posición contraria.
        // Solo se cancela lo que quede (incluidas las pendientes) y, si pasado un momento la posición no quedó en cero, ahí se aplana.
        private void OnProtectionFilled(string orderName)
        {
            if (account == null || instrument == null) return;

            closing = true;
            int epoch = Interlocked.Increment(ref closeEpoch);
            string key = account.Name + "|" + instrument.FullName;
            bool wasStop = orderName.EndsWith("SL");

            CancelAllOpen();

            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    Thread.Sleep(700);
                    if (Volatile.Read(ref closeEpoch) != epoch) return;
                    CancelAllOpen();

                    bool flat = IsFlat();
                    if (!flat)
                    {
                        account.Flatten(new[] { instrument });
                        Thread.Sleep(700);
                        if (Volatile.Read(ref closeEpoch) != epoch) return;
                        CancelAllOpen();
                        flat = IsFlat();
                    }

                    lock (globalLock) { built.Remove(key); }
                    ClearLevels();
                    if (flat) SetStatus(wasStop ? "Stop ejecutado: todo cerrado" : "TP ejecutado: todo cerrado");
                    else SetStatus("Atención: la posición sigue abierta, volvé a apretar Cerrar todo");
                    closing = false;
                }
                catch (Exception ex) { SetStatus("Error cierre: " + ex.Message); closing = false; }
            });
        }

        // Promediadas pendientes EN CONTRA (compras por debajo del precio si estás long, ventas por encima si estás short).
        // Son las que se ejecutarían antes de llegar al SL. Las que están a favor no cuentan: al ejecutarse se recalcula todo.
        // Devuelve (precio, cantidad) ordenadas de la más cercana al precio a la más lejana.
        private List<KeyValuePair<double, int>> GetAdversePending(MarketPosition dir, double refPrice)
        {
            var list = new List<KeyValuePair<double, int>>();
            bool isLong = dir == MarketPosition.Long;

            var orders = SnapshotOrders(o => o.Instrument == instrument
                && (o.Name == null || !o.Name.StartsWith("GaboProt"))
                && (isLong ? o.OrderAction == OrderAction.Buy
                    : (o.OrderAction == OrderAction.SellShort || o.OrderAction == OrderAction.Sell))
                && (o.OrderState == OrderState.Working || o.OrderState == OrderState.Accepted));

            foreach (var o in orders)
            {
                int rem = o.Quantity - o.Filled;
                if (rem <= 0) continue;

                double p;
                if (o.OrderType == OrderType.Limit) p = o.LimitPrice;
                else if (o.OrderType == OrderType.StopMarket || o.OrderType == OrderType.StopLimit) p = o.StopPrice;
                else continue;

                bool adverse = isLong ? p < refPrice : p > refPrice;
                if (adverse) list.Add(new KeyValuePair<double, int>(p, rem));
            }

            list.Sort((a, b) => isLong ? b.Key.CompareTo(a.Key) : a.Key.CompareTo(b.Key));
            return list;
        }

        // Precio de SL tal que, si se ejecutan las pendientes en contra que quedan antes de él, la pérdida total sea justo el riesgo.
        // Se prueba con 0, 1, 2... pendientes incluidas hasta encontrar la combinación consistente
        // (las incluidas quedan antes del SL y las excluidas después).
        private double ComputeStop(MarketPosition dir, int qty, double avg, double risk,
            List<KeyValuePair<double, int>> pend, out int totalQty, out int included)
        {
            bool isLong = dir == MarketPosition.Long;
            double pv = PointValue;
            int n = pend.Count;
            double stop = 0;
            totalQty = qty;
            included = 0;

            for (int k = 0; k <= n; k++)
            {
                double sumQP = qty * avg;
                int q = qty;
                for (int j = 0; j < k; j++) { sumQP += pend[j].Key * pend[j].Value; q += pend[j].Value; }

                double avgAll = sumQP / q;
                double dist = risk / (q * pv);
                stop = isLong ? avgAll - dist : avgAll + dist;
                totalQty = q;
                included = k;

                bool inclOk = k == 0 || (isLong ? pend[k - 1].Key > stop : pend[k - 1].Key < stop);
                bool exclOk = k == n || (isLong ? pend[k].Key <= stop : pend[k].Key >= stop);
                if (inclOk && exclOk) break;
            }
            return stop;
        }

        private void RebuildProtection(MarketPosition dir, int qty, double avg)
        {
            Instrument inst = instrument;
            Account acc = account;
            if (inst == null || acc == null) return;
            string key = acc.Name + "|" + inst.FullName;

            lock (globalLock)
            {
                if (closing) return;

                if (dir == MarketPosition.Flat || qty <= 0)
                {
                    built.Remove(key);
                    CancelProtection();
                    ClearLevels();
                    return;
                }

                double refPrice = lastPrice > 0 ? lastPrice : avg;
                var pend = GetAdversePending(dir, refPrice);
                string pendSig = string.Join(";", pend.Select(x => x.Key.ToString("R") + "x" + x.Value));

                // Sin cambios respecto de la última protección armada: no rearmar
                string sig = dir + "|" + qty + "|" + avg.ToString("R") + "|" + pendSig;
                string prev;
                if (built.TryGetValue(key, out prev) && prev == sig) return;
                built[key] = sig;

                double risk, profit;
                lock (cacheLock) { risk = riskCached; profit = profitCached; }

                bool isLong = dir == MarketPosition.Long;
                int totalQty, included;
                double slPrice = Round(ComputeStop(dir, qty, avg, risk, pend, out totalQty, out included));

                // Si el SL ya se movió a favor (break-even / trailing) y la posición es la misma, nunca se lo vuelve a alejar
                if (lockedStop > 0 && lockedQty == qty && Math.Abs(lockedAvg - avg) < 1e-9)
                    slPrice = isLong ? Math.Max(slPrice, lockedStop) : Math.Min(slPrice, lockedStop);
                else
                    lockedStop = 0;

                // El TP se calcula solo con lo ejecutado; si una pendiente se ejecuta, se recalcula
                double tpDist = profit / (qty * PointValue);
                double tpPrice = Round(isLong ? avg + tpDist : avg - tpDist);

                // Cambio en vivo de Riesgo/Profit: si el SL o el TP nuevos quedarían pegados o detrás del precio, no se aplica
                if (liveChange)
                {
                    liveChange = false;
                    double px = lastPrice;
                    if (px > 0)
                    {
                        double minD = MinTicksAway * inst.MasterInstrument.TickSize;
                        double slGap = isLong ? px - slPrice : slPrice - px;
                        double tpGap = isLong ? tpPrice - px : px - tpPrice;
                        if (slGap < minD || tpGap < minD)
                        {
                            // Se vuelve a los valores anteriores y la protección queda como estaba
                            built.Remove(key);
                            lock (cacheLock) { riskCached = goodRisk; profitCached = goodProfit; }
                            appliedRisk = goodRisk;
                            appliedProfit = goodProfit;
                            chartWindow.Dispatcher.InvokeAsync(() =>
                            {
                                riskBox.Text = goodRisk.ToString("0.##");
                                profitBox.Text = goodProfit.ToString("0.##");
                            });
                            SetStatus("No se aplicó: el SL o el TP nuevo quedaría pegado o detrás del precio. Se mantienen los valores anteriores (Cerrar todo si querés salir).");
                            return;
                        }
                    }
                }

                CancelProtection();

                // El SL y el TP tienen el tamaño de la posición actual. Si una pendiente se ejecuta, se vuelven a armar.
                OrderAction exitAction = isLong ? OrderAction.Sell : OrderAction.BuyToCover;
                string oco = Guid.NewGuid().ToString();

                slOrder = acc.CreateOrder(inst, exitAction, OrderType.StopMarket, OrderEntry.Manual,
                    TimeInForce.Gtc, qty, 0, slPrice, oco, "GaboProtSL", Core.Globals.MaxDate, null);
                tpOrder = acc.CreateOrder(inst, exitAction, OrderType.Limit, OrderEntry.Manual,
                    TimeInForce.Gtc, qty, tpPrice, 0, oco, "GaboProtTP", Core.Globals.MaxDate, null);

                acc.Submit(new[] { slOrder, tpOrder });

                goodRisk = risk;
                goodProfit = profit;

                PublishLevels(dir, qty, avg, slPrice, tpPrice, pend, totalQty, included);

                string msg = string.Format("{0} ctr  prom {1}  SL {2}  TP {3}", qty, avg, slPrice, tpPrice);
                if (included > 0) msg += string.Format("  (SL con {0} pendiente(s), total {1} ctr)", included, totalQty);
                if (totalQty > maxCached) msg += "  (SOBRE EL MÁXIMO de " + maxCached + ")";
                SetStatus(msg);
            }
        }

        private void CancelProtection()
        {
            var toCancel = SnapshotOrders(o => o.Instrument == instrument && o.Name != null && o.Name.StartsWith("GaboProt")
                         && !IsDone(o.OrderState));
            if (toCancel.Length > 0) account.Cancel(toCancel);
        }

        // Botón Cerrar todo: 1) bloquea el rearmado de SL/TP, 2) cancela todo lo vivo, 3) aplana,
        // 4) un instante después vuelve a cancelar lo que haya quedado y desbloquea.
        private void CloseAll()
        {
            try
            {
                if (account == null || instrument == null) return;

                closing = true;
                int epoch = Interlocked.Increment(ref closeEpoch);
                string key = account.Name + "|" + instrument.FullName;

                CancelAllOpen();
                account.Flatten(new[] { instrument });
                SetStatus("Cerrando...");

                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try
                    {
                        Thread.Sleep(800);
                        if (Volatile.Read(ref closeEpoch) != epoch) return;
                        CancelAllOpen();

                        Thread.Sleep(500);
                        if (Volatile.Read(ref closeEpoch) != epoch) return;
                        CancelAllOpen();

                        bool flat = IsFlat();
                        lock (globalLock) { built.Remove(key); }
                        ClearLevels();
                        SetStatus(flat ? "Todo cerrado" : "Atención: la posición sigue abierta, volvé a apretar Cerrar todo");
                        closing = false;
                    }
                    catch (Exception ex) { SetStatus("Error cierre: " + ex.Message); closing = false; }
                });
            }
            catch (Exception ex) { SetStatus("Error cierre: " + ex.Message); closing = false; }
        }

        // ---------- Cambiar valores sobre la marcha ----------

        // Solo hilo de la interfaz. Se llama al apretar Enter o al salir de un cuadro. Los valores se toman acá y NO mientras
        // se escribe, para que un valor a medio escribir (el 5 de 500) no mueva el SL ni cancele órdenes.
        private void ApplyLiveFields()
        {
            if (disposed) return;
            SyncFields();

            double r, p;
            lock (cacheLock) { r = riskCached; p = profitCached; }

            double dayP, dayL;
            lock (cacheLock) { dayP = dayMaxProfitCached; dayL = dayMaxLossCached; }
            GaboDayStore.SetLimits(dayP, dayL);
            TryCheckDay();

            bool riskProfitChanged = r != appliedRisk || p != appliedProfit;
            appliedRisk = r;
            appliedProfit = p;

            if (riskProfitChanged && account != null && instrument != null)
            {
                // Si hay posición abierta, reubica el SL y el TP con los valores nuevos
                string key = account.Name + "|" + instrument.FullName;
                lock (globalLock) { built.Remove(key); }
                liveChange = true;
                ScheduleRebuild();
            }

            SetStatus(string.Format("Aplicado: riesgo ${0}, profit ${1}, BE ${2} (colchón ${5}), trailing ${3}, máx {4}", r, p, beCached, trailCached, maxCached, cushionCached));
        }

        // ---------- Guardrail para órdenes nativas ----------

        // Si una orden pendiente de entrada (Buy Limit, Sell Stop, etc.) hace que posición + pendientes del mismo lado
        // superen el máximo de contratos, se cancela. Las entradas a mercado no se pueden frenar a tiempo.
        private void EnforceMaxOnPending(Order ord)
        {
            if (ord.OrderState != OrderState.Accepted && ord.OrderState != OrderState.Working) return;
            if (ord.Name == "GaboEntry") return;

            Account acc = account;
            Instrument inst = instrument;
            if (acc == null || inst == null) return;

            Position pos;
            lock (acc.Positions) pos = acc.Positions.FirstOrDefault(x => x.Instrument == inst);
            MarketPosition cur = pos != null ? pos.MarketPosition : MarketPosition.Flat;
            int curQty = pos != null ? pos.Quantity : 0;

            // ¿Esta orden suma contratos a lo que ya tengo (o abre posición)?
            Func<Order, bool> adds = o =>
                cur == MarketPosition.Long ? o.OrderAction == OrderAction.Buy
                : cur == MarketPosition.Short ? (o.OrderAction == OrderAction.Sell || o.OrderAction == OrderAction.SellShort)
                : (o.OrderAction == OrderAction.Buy || o.OrderAction == OrderAction.SellShort);

            if (!adds(ord)) return;

            int side = ord.OrderAction == OrderAction.Buy ? 1 : -1;
            var same = SnapshotOrders(o => o.Instrument == inst
                && (o.Name == null || !o.Name.StartsWith("GaboProt"))
                && (o.OrderState == OrderState.Accepted || o.OrderState == OrderState.Working)
                && adds(o)
                && (o.OrderAction == OrderAction.Buy ? 1 : -1) == side);

            int pending = same.Sum(o => o.Quantity - o.Filled);
            if (curQty + pending > maxCached)
            {
                acc.Cancel(new[] { ord });
                SetStatus(string.Format("Bloqueado: la orden pendiente pasaría el máximo de {0} contratos (posición {1} + pendientes {2})",
                    maxCached, curQty, pending));
            }
        }

        // ---------- Break-even y trailing ----------

        // Se llama en cada tick; limita la frecuencia y corre en otro hilo para no frenar los datos
        private void TryManageStop()
        {
            if (disposed || closing) return;
            if (beCached <= 0 && trailCached <= 0 && !trailBtnOn) return;
            int now = Environment.TickCount;
            if (unchecked(now - lastManage) < 150) return;
            if (Interlocked.CompareExchange(ref manageBusy, 1, 0) != 0) return;
            lastManage = now;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try { ManageStop(); }
                catch (Exception ex) { SetStatus("Error BE/trailing: " + ex.Message); }
                finally { Interlocked.Exchange(ref manageBusy, 0); }
            });
        }

        // Break-even: cuando la ganancia abierta llega a Break-even $, el SL pasa al precio promedio.
        // Trailing: cuando la ganancia llega a Trailing $, el SL va detrás del precio a esa distancia en USD.
        // El SL solo se mueve a favor, nunca se aleja.
        private void ManageStop()
        {
            Account acc = account;
            Instrument inst = instrument;
            if (disposed || closing || acc == null || inst == null || lastPrice <= 0) return;

            double be, tr, cush, rk;
            lock (cacheLock) { be = beCached; tr = trailCached; cush = cushionCached; rk = profitCached; }
            // Botón Trailing en ON sin valor cargado: distancia = fracción del Profit $ (empieza a seguir recién cuando ya ganás esa cantidad)
            if (tr <= 0 && trailBtnOn) tr = rk * TrailDefaultFraction;
            if (be <= 0 && tr <= 0) return;

            lock (globalLock)
            {
                if (closing) return;

                Position pos;
                lock (acc.Positions) pos = acc.Positions.FirstOrDefault(x => x.Instrument == inst);
                if (pos == null || pos.MarketPosition == MarketPosition.Flat || pos.Quantity <= 0) return;

                bool isLong = pos.MarketPosition == MarketPosition.Long;
                int q = pos.Quantity;
                double avg = pos.AveragePrice;
                double pv = PointValue;
                double tick = inst.MasterInstrument.TickSize;
                double price = lastPrice;
                double sign = isLong ? 1 : -1;
                double profit = (price - avg) * q * pv * sign;

                var sl = SnapshotOrders(o => o.Instrument == inst && o.Name == "GaboProtSL"
                    && (o.OrderState == OrderState.Working || o.OrderState == OrderState.Accepted)).FirstOrDefault();
                if (sl == null) return;
                if (sl.Quantity != q) return;   // la protección se está rearmando con otro tamaño

                double cur = sl.StopPrice;
                double target = cur;
                string why = null;

                if (be > 0 && profit >= be)
                {
                    double cand = BeLevel(isLong, avg, q, cush);
                    if (isLong ? cand > target : cand < target) { target = cand; why = "Break-even"; }
                }
                if (tr > 0 && profit >= tr)
                {
                    double dist = tr / (q * pv);
                    double cand = Round(isLong ? price - dist : price + dist);
                    if (cush > 0)
                    {
                        // El trailing nunca deja el SL por debajo de entrada + colchón
                        double floor = BeLevel(isLong, avg, q, cush);
                        cand = isLong ? Math.Max(cand, floor) : Math.Min(cand, floor);
                    }
                    if (isLong ? cand > target : cand < target) { target = cand; why = "Trailing"; }
                }

                if (why == null || Math.Abs(target - cur) < tick * 0.5) return;

                // Ya se mandó este mismo precio y la orden todavía no confirmó el cambio
                if (lockedStop > 0 && lockedQty == q && Math.Abs(lockedAvg - avg) < 1e-9 && Math.Abs(lockedStop - target) < tick * 0.5) return;

                // El stop tiene que quedar al menos un tick del lado correcto del precio
                if (isLong ? target > price - tick : target < price + tick) return;

                sl.StopPriceChanged = target;
                acc.Change(new[] { sl });

                lockedStop = target;
                lockedQty = q;
                lockedAvg = avg;

                double pnl = (target - avg) * q * pv * sign;
                RepublishSl(target, pnl, why);
                SetStatus(string.Format("{0}: SL movido a {1} ({2})", why, target, Usd(pnl)));
            }
        }

        // ---------- Límite diario: ganancia máxima y pérdida máxima ----------

        // Se llama en cada tick; limita la frecuencia y corre en otro hilo
        private void TryCheckDay()
        {
            if (disposed) return;
            int now = Environment.TickCount;
            if (unchecked(now - lastDayCheck) < 300) return;
            if (Interlocked.CompareExchange(ref dayBusy, 1, 0) != 0) return;
            lastDayCheck = now;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try { EvaluateDay(); }
                catch (Exception ex) { SetStatus("Error día: " + ex.Message); }
                finally { Interlocked.Exchange(ref dayBusy, 0); }
            });
        }

        // Resultado del día = PnL realizado desde el punto de partida del día + PnL abierto de la cuenta.
        // Si llega a la ganancia máxima o a la pérdida máxima: cierra todo, cancela todo y bloquea hasta el día siguiente.
        // Devuelve true si el día está bloqueado.
        private bool EvaluateDay()
        {
            Account acc = account;
            if (acc == null) return dayLocked;

            DateTime today = DateTime.Now.Date;
            double realized = acc.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
            double open = acc.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
            GaboDayInfo info = GaboDayStore.Get(acc.Name, today, realized);
            double pnl = realized - info.Baseline + open;

            double maxP, maxL;
            lock (cacheLock) { maxP = dayMaxProfitCached; maxL = dayMaxLossCached; }

            if (info.Lock == null)
            {
                string reason = null;
                if (maxP > 0 && pnl >= maxP) reason = "ganancia máxima del día";
                else if (maxL > 0 && pnl <= -maxL) reason = "pérdida máxima del día";
                if (reason != null)
                {
                    GaboDayStore.SetLock(acc.Name, today, reason, realized);
                    dayLocked = true;
                    dayLockReason = reason;
                    LockAndFlatten(string.Format("Se llegó a la {0} ({1}): se cierra todo y se bloquea hasta mañana.", reason, Usd(pnl)));
                }
            }

            dayLocked = info.Lock != null;
            dayLockReason = info.Lock ?? "";
            ShowDay(pnl, maxP, maxL, info.Lock);
            return dayLocked;
        }

        private void ShowDay(double pnl, double maxP, double maxL, string lockReason)
        {
            string text = "Día: " + Usd(pnl);
            if (maxP > 0 || maxL > 0) text += string.Format("   (máx +${0} / -${1})", maxP.ToString("0.##"), maxL.ToString("0.##"));
            if (lockReason != null) text = "BLOQUEADO hasta mañana: " + lockReason + "\n" + text;
            bool locked = lockReason != null;
            if (text == lastDayText && locked == lastDayLocked) return;
            lastDayText = text;
            lastDayLocked = locked;
            try
            {
                chartWindow.Dispatcher.InvokeAsync(() =>
                {
                    if (dayText == null) return;
                    dayText.Text = text;
                    dayText.Foreground = locked ? Brushes.OrangeRed : Brushes.LightGray;
                });
            }
            catch { }
        }

        private void CancelEverything(Account acc)
        {
            Order[] open;
            lock (acc.Orders) open = acc.Orders.Where(o => !IsDone(o.OrderState)).ToArray();
            if (open.Length > 0) acc.Cancel(open);
        }

        private void FlattenEverything(Account acc)
        {
            Instrument[] ins;
            lock (acc.Positions) ins = acc.Positions.Where(p => p.MarketPosition != MarketPosition.Flat).Select(p => p.Instrument).ToArray();
            if (ins.Length > 0) acc.Flatten(ins);
        }

        private bool AllFlat(Account acc)
        {
            lock (acc.Positions) return !acc.Positions.Any(p => p.MarketPosition != MarketPosition.Flat);
        }

        // Cancela todo lo vivo de la cuenta y aplana todas sus posiciones (no solo la del instrumento de este gráfico)
        private void LockAndFlatten(string msg)
        {
            Account acc = account;
            if (acc == null) return;

            dayLocked = true;
            closing = true;
            int epoch = Interlocked.Increment(ref closeEpoch);
            SetStatus(msg);

            try
            {
                CancelEverything(acc);
                FlattenEverything(acc);
            }
            catch (Exception ex) { SetStatus("Error al cerrar: " + ex.Message); }

            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    Thread.Sleep(800);
                    if (Volatile.Read(ref closeEpoch) != epoch) return;
                    CancelEverything(acc);
                    if (!AllFlat(acc))
                    {
                        FlattenEverything(acc);
                        Thread.Sleep(700);
                        CancelEverything(acc);
                    }

                    Instrument inst = instrument;
                    if (inst != null) lock (globalLock) { built.Remove(acc.Name + "|" + inst.FullName); }
                    ClearLevels();
                    SetStatus(AllFlat(acc) ? msg : "Atención: el día quedó bloqueado pero una posición sigue abierta, apretá Cerrar todo");
                    closing = false;
                }
                catch (Exception ex) { SetStatus("Error cierre: " + ex.Message); closing = false; }
            });
        }

        // Botón Reiniciar día: desbloquea y vuelve a contar el día desde cero. Pide confirmación.
        private void ResetDay()
        {
            try
            {
                ConnectAccount();
                if (account == null) { SetStatus("Sin cuenta seleccionada"); return; }
                if (MessageBox.Show("¿Reiniciar el día? Se desbloquea y el resultado del día vuelve a $0.", "GaboRisk",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

                double realized = account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
                GaboDayStore.Reset(account.Name, DateTime.Now.Date, realized);
                dayLocked = false;
                dayLockReason = "";
                lastDayText = null;
                SetStatus("Día reiniciado");
                TryCheckDay();
            }
            catch (Exception ex) { SetStatus("Error al reiniciar el día: " + ex.Message); }
        }

        // ---------- Botones: break-even y trailing con un toque ----------

        // Precio de break-even con colchón: entrada + colchón en USD / (contratos x valor del punto).
        // Se redondea hacia el lado de la ganancia, así el colchón nunca queda por debajo de lo pedido.
        private double BeLevel(bool isLong, double avg, int qty, double cushionUsd)
        {
            double tick = instrument.MasterInstrument.TickSize;
            double raw = avg + (isLong ? 1 : -1) * (cushionUsd / (qty * PointValue));
            double n = isLong ? Math.Ceiling(raw / tick - 1e-9) : Math.Floor(raw / tick + 1e-9);
            return instrument.MasterInstrument.RoundToTickSize(n * tick);
        }

        // Mueve el SL a 'target' solo si queda más a favor que el actual y al menos un tick del lado correcto del precio.
        // Lo usan el botón BE y el arrastre de la zona roja hacia el lado de la ganancia.
        private bool MoveStopTo(double target, string tag, out string why)
        {
            why = null;
            Account acc = account;
            Instrument inst = instrument;
            if (acc == null || inst == null) { why = "sin cuenta o instrumento"; return false; }

            lock (globalLock)
            {
                if (closing) { why = "se está cerrando la posición"; return false; }

                Position pos;
                lock (acc.Positions) pos = acc.Positions.FirstOrDefault(x => x.Instrument == inst);
                if (pos == null || pos.MarketPosition == MarketPosition.Flat || pos.Quantity <= 0) { why = "no hay posición abierta"; return false; }

                bool isLong = pos.MarketPosition == MarketPosition.Long;
                int q = pos.Quantity;
                double avg = pos.AveragePrice;
                double pv = PointValue;
                double tick = inst.MasterInstrument.TickSize;
                double sign = isLong ? 1 : -1;

                var sl = SnapshotOrders(o => o.Instrument == inst && o.Name == "GaboProtSL"
                    && (o.OrderState == OrderState.Working || o.OrderState == OrderState.Accepted)).FirstOrDefault();
                if (sl == null) { why = "no encuentro el SL activo"; return false; }
                if (sl.Quantity != q) { why = "la protección se está rearmando, probá de nuevo"; return false; }

                if (sign * (target - sl.StopPrice) < tick * 0.5) { why = "el SL ya está en ese nivel o más a favor"; return false; }

                double price = lastPrice;
                if (price > 0 && sign * (price - target) < tick)
                {
                    why = string.Format("el precio todavía no llegó a {0}", target);
                    return false;
                }

                sl.StopPriceChanged = target;
                acc.Change(new[] { sl });

                lockedStop = target;
                lockedQty = q;
                lockedAvg = avg;

                double pnl = (target - avg) * q * pv * sign;
                RepublishSl(target, pnl, tag);
                SetStatus(string.Format("{0}: SL movido a {1} ({2})", tag, target, Usd(pnl)));
                return true;
            }
        }

        // Botón BE ya: el SL pasa a entrada + colchón (cubre comisiones). Solo si el precio ya está lo bastante a favor.
        private void BreakEvenNow()
        {
            try
            {
                RefreshInstrument();
                ConnectAccount();
                if (account == null || instrument == null) { SetStatus("Sin cuenta o instrumento"); return; }
                SyncFields();

                Position pos;
                lock (account.Positions) pos = account.Positions.FirstOrDefault(x => x.Instrument == instrument);
                if (pos == null || pos.MarketPosition == MarketPosition.Flat || pos.Quantity <= 0) { SetStatus("BE: no hay posición abierta"); return; }

                double cush;
                lock (cacheLock) cush = cushionCached;
                double target = BeLevel(pos.MarketPosition == MarketPosition.Long, pos.AveragePrice, pos.Quantity, cush);

                string why;
                if (!MoveStopTo(target, "Break-even", out why)) SetStatus("BE no aplicado: " + why);
            }
            catch (Exception ex) { SetStatus("Error BE: " + ex.Message); }
        }

        // Botón Trailing: lo prende o lo apaga. Sin valor en Trailing $ usa la mitad del Profit $ como distancia.
        // Empieza a seguir al precio cuando la ganancia llega a esa distancia, o sea que el SL arranca en break-even
        // (con el colchón) y de ahí sube detrás del precio. El SL solo se mueve a favor. Vale para una operación.
        private void ToggleTrailing()
        {
            try
            {
                if (trailBtnOn)
                {
                    trailBtnOn = false;
                    UpdateTrailButton();
                    SetStatus("Trailing apagado: el SL queda donde está");
                    return;
                }

                RefreshInstrument();
                ConnectAccount();
                if (account == null || instrument == null) { SetStatus("Sin cuenta o instrumento"); return; }
                if (IsFlat()) { SetStatus("Trailing: no hay posición abierta, prendelo cuando estés adentro"); return; }

                SyncFields();
                trailBtnOn = true;
                UpdateTrailButton();

                double tr, rk, cush;
                lock (cacheLock) { tr = trailCached; rk = profitCached; cush = cushionCached; }
                double dist = tr > 0 ? tr : rk * TrailDefaultFraction;
                SetStatus(string.Format("Trailing ON: sigue al precio a ${0} y arranca cuando ganás ${0} (nunca por debajo de entrada + ${1})",
                    dist.ToString("0.##"), cush.ToString("0.##")));
                TryManageStop();
            }
            catch (Exception ex) { SetStatus("Error trailing: " + ex.Message); }
        }

        private void UpdateTrailButton()
        {
            try
            {
                chartWindow.Dispatcher.InvokeAsync(() =>
                {
                    if (trailBtn == null) return;
                    trailBtn.Content = BtnText(trailBtnOn ? "Trailing: ON" : "Trailing: OFF");
                    if (trailBtnOn) trailBtn.Background = Brushes.SeaGreen;
                    else trailBtn.ClearValue(Control.BackgroundProperty);
                });
            }
            catch { }
        }

        // ---------- Zonas arrastrables ----------

        // Llega del indicador cuando soltás el TP o el SL en un lugar nuevo
        private void OnZoneDragged(string instrumentName, int kind, double price, object owner)
        {
            if (disposed) return;
            if (owner != null && !object.ReferenceEquals(owner, chartWindow)) return;   // solo el panel del gráfico donde arrastraste
            try { chartWindow.Dispatcher.InvokeAsync(() => ApplyZoneDrag(instrumentName, kind, price)); }
            catch { }
        }

        private void RejectDrag(string why)
        {
            SetStatus("No se aplicó: " + why);
            GaboLevels.Touch();   // el indicador vuelve a mostrar la zona donde estaba
            RefreshChart();
        }

        // Solo hilo de la interfaz. Arrastrar el TP cambia Profit $; arrastrar el SL cambia Riesgo $.
        // Si el SL se arrastra más allá de la entrada, hacia la ganancia, se mueve la orden como un break-even manual.
        private void ApplyZoneDrag(string instrumentName, int kind, double price)
        {
            try
            {
                if (disposed || closing || account == null || instrument == null || instrument.FullName != instrumentName) return;

                GaboLevel[] lv = GaboLevels.Get(instrumentName);
                double avg, sign; int qty;
                if (!GaboLevels.Basis(lv, out avg, out qty, out sign)) return;

                double tick = instrument.MasterInstrument.TickSize;
                double minD = MinTicksAway * tick;
                double px = lastPrice;
                price = Round(price);

                if (kind == 0)
                {
                    double tpPnl = GaboLevels.TargetPnl(lv, price, PointValue);
                    if (tpPnl < 1) { RejectDrag("el TP tiene que quedar del lado de la ganancia"); return; }
                    if (px > 0 && sign * (price - px) < minD) { RejectDrag("el TP quedaría pegado o detrás del precio"); return; }
                    SetRiskOrProfit(false, tpPnl, "TP");
                    return;
                }

                if (px > 0 && sign * (px - price) < minD) { RejectDrag("el SL quedaría pegado o del otro lado del precio"); return; }
                double slPnl = GaboLevels.StopPnl(lv, price, PointValue);
                if (slPnl >= 0)
                {
                    string why;
                    if (!MoveStopTo(price, "Zona", out why)) RejectDrag(why);
                    return;
                }
                SetRiskOrProfit(true, -slPnl, "SL");
            }
            catch (Exception ex) { SetStatus("Error zona: " + ex.Message); }
        }

        // Solo hilo de la interfaz. Hace lo mismo que escribir el valor en el cuadro y apretar Enter.
        private void SetRiskOrProfit(bool isRisk, double usd, string tag)
        {
            double v = Math.Round(usd, 2);
            if (v < 1) { RejectDrag("el valor quedaría en menos de $1"); return; }

            lock (cacheLock)
            {
                if (isRisk) riskCached = v; else profitCached = v;
            }
            if (isRisk)
            {
                appliedRisk = v;
                lockedStop = 0;   // arrastrar el SL hacia atrás es una decisión tuya: se suelta el SL que había subido el BE o el trailing
                riskBox.Text = v.ToString("0.##");
            }
            else
            {
                appliedProfit = v;
                profitBox.Text = v.ToString("0.##");
            }

            string key = account.Name + "|" + instrument.FullName;
            lock (globalLock) { built.Remove(key); }
            liveChange = true;
            ScheduleRebuild();
            SetStatus(string.Format("Zona {0}: {1} ${2}", tag, isRisk ? "riesgo" : "profit", v.ToString("0.##")));
        }

        // Actualiza solo el nivel del SL en el panel y en el gráfico
        private void RepublishSl(double stop, double pnl, string tag)
        {
            try
            {
                Instrument inst = instrument;
                if (inst == null) return;
                GaboLevel[] cur = GaboLevels.Get(inst.FullName);
                if (cur == null) return;

                var lv = new List<GaboLevel>();
                foreach (var l in cur)
                {
                    if (l.Kind == 3 || l.Kind == 4)
                        lv.Add(new GaboLevel { Price = stop, Kind = 3, Text = string.Format("SL {0} ({1})", Usd(pnl), tag) });
                    else lv.Add(l);
                }
                lv.Sort((a, b) => b.Price.CompareTo(a.Price));

                var sb = new System.Text.StringBuilder();
                foreach (var l in lv) sb.AppendLine(l.Price.ToString("0.00") + "  " + l.Text);

                GaboLevels.Set(inst.FullName, lv.ToArray());
                SetLevelsText(sb.ToString().TrimEnd());
                RefreshChart();
            }
            catch { }
        }

        // ---------- Niveles (panel + indicador del gráfico) ----------

        private static string Usd(double v)
        {
            return (v < 0 ? "-$" : "+$") + Math.Abs(v).ToString("0");
        }

        // Arma la lista de niveles: TP, entrada, pendientes en contra y SL (con las pendientes ejecutadas si las hay).
        // La muestra en el panel y se la pasa al indicador GaboRiskLines.
        private void PublishLevels(MarketPosition dir, int qty, double avg, double slPrice, double tpPrice,
            List<KeyValuePair<double, int>> pend, int totalQty, int included)
        {
            try
            {
                Instrument inst = instrument;
                if (inst == null) return;

                double pv = PointValue;
                double sign = dir == MarketPosition.Long ? 1 : -1;
                var lv = new List<GaboLevel>();

                double tpPnl = (tpPrice - avg) * qty * pv * sign;
                lv.Add(new GaboLevel { Price = tpPrice, Kind = 0, Text = string.Format("TP {0} ({1} ctr)", Usd(tpPnl), qty) });
                lv.Add(new GaboLevel { Price = avg, Kind = 1, Qty = qty, Text = string.Format("Entrada {0} ctr", qty) });

                foreach (var pe in pend)
                {
                    double pnl = (pe.Key - avg) * qty * pv * sign;   // resultado de lo que ya tenés abierto si el precio llega ahí
                    lv.Add(new GaboLevel { Price = pe.Key, Kind = 2, Qty = pe.Value,
                        Text = string.Format("Pend. {0} ctr: {1} ({2:0.##} pts)", pe.Value, Usd(pnl), Math.Abs(pe.Key - avg)) });
                }

                // Resultado total si salta el SL, contando las pendientes que se ejecutan antes
                double slPnl = (slPrice - avg) * qty * pv * sign;
                for (int j = 0; j < included && j < pend.Count; j++)
                    slPnl += (slPrice - pend[j].Key) * pend[j].Value * pv * sign;
                lv.Add(new GaboLevel { Price = slPrice, Kind = included > 0 ? 4 : 3,
                    Text = included > 0 ? string.Format("SL {0} (total {1} ctr si se llenan)", Usd(slPnl), totalQty)
                                        : string.Format("SL {0}", Usd(slPnl)) });

                lv.Sort((a, b) => b.Price.CompareTo(a.Price));

                var sb = new System.Text.StringBuilder();
                foreach (var l in lv) sb.AppendLine(l.Price.ToString("0.00") + "  " + l.Text);

                GaboLevels.Set(inst.FullName, lv.ToArray());
                SetLevelsText(sb.ToString().TrimEnd());
                RefreshChart();
            }
            catch (Exception ex) { SetStatus("Error niveles: " + ex.Message); }
        }

        private void ClearLevels()
        {
            try
            {
                lockedStop = 0;
                if (trailBtnOn) { trailBtnOn = false; UpdateTrailButton(); }   // el trailing por botón vale para una operación
                if (instrument != null) GaboLevels.Set(instrument.FullName, null);
                SetLevelsText("");
                RefreshChart();
            }
            catch { }
        }

        private void SetLevelsText(string text)
        {
            try
            {
                chartWindow.Dispatcher.InvokeAsync(() => { if (levelsText != null) levelsText.Text = text; });
            }
            catch { }
        }

        private void RefreshChart()
        {
            try
            {
                chartWindow.Dispatcher.InvokeAsync(() =>
                {
                    try { if (chartWindow.ActiveChartControl != null) chartWindow.ActiveChartControl.InvalidateVisual(); }
                    catch { }
                });
            }
            catch { }
        }

        private void SetStatus(string text)
        {
            try
            {
                chartWindow.Dispatcher.InvokeAsync(() => { if (statusText != null) statusText.Text = text; });
            }
            catch { }
        }
    }
}